---
title: Bash Notes
menu:
  notes:
    name: Bash
    identifier: notes-bash
    weight: 20
---
# Bash Notes