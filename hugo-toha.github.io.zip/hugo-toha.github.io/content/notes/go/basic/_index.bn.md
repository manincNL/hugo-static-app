---
title: Go বেসিক
weight: 10
menu:
  notes:
    name: বেসিক
    identifier: notes-go-basics
    parent: notes-go
    weight: 10
---
