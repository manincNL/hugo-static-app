---
title: Basics
weight: 10
menu:
  notes:
    name: Basics
    identifier: notes-go-basics
    parent: notes-go
    weight: 10
---
