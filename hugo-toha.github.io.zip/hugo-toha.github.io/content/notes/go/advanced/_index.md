---
title: Advanced
weight: 20
menu:
  notes:
    name: Advanced
    identifier: notes-go-advanced
    parent: notes-go
    weight: 20
---
